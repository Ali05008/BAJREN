import 'package:flutter/material.dart';

import 'account_screen.dart';
import 'blocked_users_screen.dart';
import 'general_screen.dart';
import 'notifications_screen.dart';
import 'privacy_screen.dart';
import 'security_screen.dart';

/// Settings screen structure. Every section now has a real destination.
class SettingsPlaceholderScreen extends StatelessWidget {
  const SettingsPlaceholderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final sections = <_SettingsSection>[
      _SettingsSection(
        'الحساب',
        Icons.account_circle_outlined,
        builder: (_) => const AccountScreen(),
      ),
      _SettingsSection(
        'الخصوصية',
        Icons.lock_outline,
        builder: (_) => const PrivacyScreen(),
      ),
      _SettingsSection(
        'الأمان',
        Icons.security_outlined,
        builder: (_) => const SecurityScreen(),
      ),
      _SettingsSection(
        'الإشعارات',
        Icons.notifications_outlined,
        builder: (_) => const NotificationsScreen(),
      ),
      _SettingsSection(
        'المستخدمون المحظورون',
        Icons.block_outlined,
        builder: (_) => const BlockedUsersScreen(),
      ),
      _SettingsSection(
        'عام',
        Icons.tune_outlined,
        builder: (_) => const GeneralScreen(),
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView.separated(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: sections.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final section = sections[index];
          return ListTile(
            leading: Icon(section.icon),
            title: Text(section.title),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: section.builder),
            ),
          );
        },
      ),
    );
  }
}

class _SettingsSection {
  const _SettingsSection(this.title, this.icon, {required this.builder});
  final String title;
  final IconData icon;
  final WidgetBuilder builder;
}
