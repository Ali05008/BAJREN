import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/presentation/providers/auth_providers.dart';
import '../../data/account_repository.dart';
import '../providers/account_providers.dart';
import 'blocked_users_screen.dart';

/// Privacy screen. "من يقدر يضيفني كجهة اتصال" is real and enforced by
/// RTDB rules (see docs/firebase_database.rules.json — public_profiles
/// becomes unreadable to non-owners once discoverable is false). The
/// rest are still placeholders pending their own phases.
class PrivacyScreen extends ConsumerWidget {
  const PrivacyScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final profileAsync = ref.watch(accountProfileProvider);
    final discoverable = profileAsync.valueOrNull?.discoverable ?? true;

    return Scaffold(
      appBar: AppBar(title: const Text('الخصوصية')),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: [
          SwitchListTile(
            secondary: const Icon(Icons.person_add_alt_outlined),
            title: const Text('السماح للآخرين بإضافتي كجهة اتصال'),
            subtitle: Text(discoverable ? 'مفعّل — أي مستخدم يقدر يضيفك' : 'معطّل — ما يقدر أحد يضيفك من جديد'),
            value: discoverable,
            onChanged: user == null
                ? null
                : (value) async {
                    try {
                      await ref.read(accountRepositoryProvider).updateDiscoverable(
                            uid: user.uid,
                            discoverable: value,
                          );
                    } on AccountException catch (e) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context)
                            .showSnackBar(SnackBar(content: Text(e.message)));
                      }
                    }
                  },
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.circle_outlined),
            title: const Text('من يشوف حالة الاتصال (متصل الآن)'),
            subtitle: const Text('الكل (افتراضي)'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _comingSoon(context, 'حالة الاتصال'),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.call_outlined),
            title: const Text('من يقدر يتصل بي'),
            subtitle: const Text('الكل (افتراضي)'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _comingSoon(context, 'من يقدر يتصل بي'),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.block_outlined),
            title: const Text('المستخدمون المحظورون'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const BlockedUsersScreen()),
            ),
          ),
        ],
      ),
    );
  }

  void _comingSoon(BuildContext context, String label) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('$label — قريبًا')));
  }
}
